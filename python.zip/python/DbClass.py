import pymysql, time, random, json

class DbClass:
    
    dsn = None

    whereParse = ""
    fieldParse = "*"
    tableName = ""
    sql = ""

    def __init__(self, config = []):
        # 初始化操作
        host = config['host']
        user = config['user']
        passwd = config['passwd']
        database = config['database']
        charset = config['charset']
        option = config['option']

        self.dsn = pymysql.connect(host=host, user=user, password=passwd, database=database, charset=charset, cursorclass=option)

    def table(self, table=""):
        # 数据表名称
        self.tableName = table
        return self

    def where(self, where=[]):
        # 条件查询
        for key, val in where.items():
            if isinstance(val, list):
                if val[0] == "between":
                    self.whereParse += " and " + key + " " + val[0] + " " + str(val[1][0]) + " and " + str(val[1][1])
                    continue
                elif val[0] in [">", "<"]:
                    self.whereParse += " and " + key + " " + val[0] + " " + str(val[1])
                    continue
                
            self.whereParse += " and " + key + "=" + str(val)
        print(self.whereParse[3:3])
        exit()
        self.whereParse = self.whereParse.strip(' and')
        return self

    def field(self, field):
        if isinstance(field, str):
            self.fieldParse = field

        if isinstance(field, dict):
            # 以逗号拆分
            pass
        return self

    def find(self):
        self.sql = "select " + self.fieldParse + " from " + self.tableName + " where " + self.whereParse
        return self.sql

    def insert(self, data):
        if isinstance(data, dict) == False:
            # isinstance(data, list) == False | 
            raise '错误的数据!'
        # 编译sql语句
        prepare = ""
        parm = ""
        data_value = []
        for key, val in data.items():
            prepare += key + ","
            parm += "%s,"
            data_value.append(val)
        prepare = prepare.strip(",")
        parm = parm.strip(",")
        # 准备执行sql
        self.sql = "insert " + self.tableName + "(" + prepare + ") values (" + parm + ")"
        cursor = self.dsn.cursor()
        try:
            # 写入数据
            bool_back = cursor.execute(self.sql, data_value)
            if bool_back == 0:
                return "新增失败!"
            self.dsn.commit()

        except Exception as error:
            self.dsn.rollback()
            raise error

        return cursor.lastrowid

    def insertMany(self, data):
        if isinstance(data, dict) == False:
            raise '错误的数据!'
        # 编译sql语句
        prepare = ""
        parm = ""
        data_one = data[0]
        data_value = []
        for val in data_one:
            prepare += val + ","
            parm += "%s,"
        prepare = prepare.strip(",")
        parm = parm.strip(",")
        
        # 编译数据
        for val_d in data.values():
            data_value.append(list(val_d.values()))

        self.sql = "insert " + self.tableName + "(" + prepare + ") values (" + parm + ")"
        cursor = self.dsn.cursor()
        try:
            # 写入数据
            bool_back = cursor.executemany(self.sql, data_value)
            if bool_back == 0:
                return "批量新增失败!"
            # 提交事务
            self.dsn.commit()

        except Exception as error:
            # 失败后回滚数据
            self.dsn.rollback()
            raise error

        return bool_back

    def __del__(self):
        self.dsn.close()
        print("---------------------is over---------------------")


