import pymysql
import time
import random
import json

conn = pymysql.connect(host = "127.0.0.1", user = "root", password = "765876", database = "lovelive", charset = "utf8mb4", cursorclass = pymysql.cursors.DictCursor)
cursor = conn.cursor()
sql = "select * from py_user where id=%s"
sql2 = """insert py_user(name, age, mobile, updatetime) 
VALUE
(%s, %s, %s, %s)
"""
sql3 = "update py_user set age=%s where id = 2"

data = []
unix_time = time.time()
for i in range(0, 6):
    data.append(("TypeMoon" + str(i + 1), int(random.randint(22, 33)), str(random.randint(15123230000, 15123239999)), int(unix_time - random.randint(20, 50000))))

data_one = ["LoveLive_1", int(random.randint(22, 33)), str(random.randint(15123230000, 15123239999)), int(unix_time - random.randint(20, 50000))]


try:
    bool_back = cursor.execute(sql, [1])
    # 批量添加, 执行时不能使用获取自增id
    # bool_back = cursor.executemany(sql2, data)
    # 取出所有数据
    # result = cursor.fetchall()

    # fetchone每次查询会移动指针至下一个
    result_one = cursor.fetchone()
    # result_two = cursor.fetchone()
    
    # 获取自增id
    last_id = cursor.lastrowid
    conn.commit()
    
    # json_str = json.loads(result_one)
    print(result_one['name'])

except Exception as error:
    conn.rollback()
    # cursor.execute("truncate py_user")
    print(error)

cursor.close()
conn.close()

