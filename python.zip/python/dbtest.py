import pymysql, time, random, json, sys
from DbClass import DbClass

sys.path.append("F:\\www\\honoka\\python")

config = {
    "host": "127.0.0.1",
    "user": "root",
    "passwd": "765876",
    "database": "lovelive",
    "charset": "utf8mb4",
    "option": pymysql.cursors.DictCursor,
}



unix_time = time.time()
data = {"age": 23,"name": "Honoka","mobile": "15623330001","updatetime": int(time.time() - random.randint(20, 50000))}
data_more = {
    0: {
        "age": 23,
        "name": "Umi",
        "mobile": "15623330002",
        "updatetime": int(unix_time - random.randint(20, 50000))
    },
    1: {
        "age": 23,
        "name": "Kotori",
        "mobile": "15623330003",
        "updatetime": int(unix_time - random.randint(20, 50000))
    }
}

db = DbClass(config)
where = {"age": ["between", [23, 26]], "updatetime": ["<", 1512323212], "id": 1}
sql = db.table("py_user").where(where).field('id,name,age,mobile').find()

# sql = db.table("py_user").insert(data)
# sql = db.table("py_user").insertMany(data_more)
print(sql)