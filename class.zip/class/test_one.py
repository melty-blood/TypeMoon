import pymysql
import time
import random
import json

conn = pymysql.connect(host = "127.0.0.1", user = "root", password = "765876", database = "lovelive", charset = "utf8mb4", cursorclass = pymysql.cursors.DictCursor)
cursor = conn.cursor()
sql = "select * from py_user where id in(%s) and age between %s and %s"
sql2 = """insert py_user(name, age, mobile, updatetime) 
VALUE
(%s, %s, %s, %s)
"""
sql3 = "update py_user set age=%s where id = 2"

data = []
unix_time = time.time()
for i in range(0, 6):
    data.append(("TypeMoon" + str(i + 1), int(random.randint(22, 33)), str(random.randint(15123230000, 15123239999)), int(unix_time - random.randint(20, 50000))))

data_one = ["LoveLive_1", int(random.randint(22, 33)), str(random.randint(15123230000, 15123239999)), int(unix_time - random.randint(20, 50000))]


try:
    bool_back = cursor.execute(sql, ["4,5", 22, 24])
    # 批量添加, 执行时不能使用获取自增id
    # bool_back = cursor.executemany(sql2, data)
    # 取出所有数据
    result = cursor.fetchall()

    # fetchone每次查询会移动指针至下一个
    # result_one = cursor.fetchone()
    # result_two = cursor.fetchone()
    
    # 获取自增id
    last_id = cursor.lastrowid
    conn.commit()
    
    # json_str = json.loads(result_one)
    print(result)

except Exception as error:
    conn.rollback()
    # cursor.execute("truncate py_user")
    print(error)

cursor.close()
conn.close()

# 旧版本
# def where(self, where=[]):
#         # 条件查询
#         for key, val in where.items():
#             if isinstance(val, list):
#                 if val[0] == "between":
#                     self.whereParse += key + " " + val[0] + " " + str(val[1][0]) + " and " + str(val[1][1]) + " and "
#                     self.prepare_parm_list.append(str(val[1][0]))
#                     self.prepare_parm_list.append(str(val[1][1]))
#                     continue
#                 elif val[0] in [">", "<", ">=", "<=", "<>"]:
#                     self.prepare_parm_list.append(str(val[1]))
#                     self.whereParse += key + " " + val[0] + " " + str(val[1]) + " and "
#                     continue
#                 elif val[0] == "in":
#                     id_list = val[1]
#                     prepare_count = "%s," * (id_list.count(",") + 1)
#                     prepare_count = prepare_count.rstrip(",")
#                     self.prepare_parm_list.extend(id_list.split(","))
#                     self.whereParse += key + " " + val[0] + "(" + str(val[1]) + ") and "
#                     continue
#             self.whereParse += key + "=" + str(val) + " and "
#             self.prepare_parm_list.append(str(val))
#         print(self.prepare_parm_list)
#         exit()
#         # self.whereParse = self.whereParse.rstrip()
#         # self.whereParse[4:len(self.whereParse)]
#         self.whereParse = self.whereParse.rstrip(" and ")
#         return self
