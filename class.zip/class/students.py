

class Student:
    count = 0
    age = None

    def __init__(self, name, score):
        self.name = name
        self.score = score
        Student.count = Student.count + 1
     
    def sayName(self):
        return "{0} 的分数是: {1}".format(self.name, self.score)

    @classmethod
    def classFunc(cls, any):

        return any + "_22@33_ ~!", cls.age

    @staticmethod
    def staticFunc(any):

        return any + "__lililili"

    def __call__(self, any):
        some = "__22@33__ ~!"
        if (isinstance(any, int) == True) :
            return any + 23
        else :
            some = "__bilibili ~!"
        
        return  "{0} -- What {1} !!".format(some, any)



    def __del__(self):
        pass



s1 = Student("TypeMoon", 23)
# s2 = Student("Tsukihime", "asd")
print(s1("12"))